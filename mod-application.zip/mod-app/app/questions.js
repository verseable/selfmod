// ─────────────────────────────────────────────────────────────────────────
//  EDIT THIS FILE TO CUSTOMIZE YOUR APPLICATION
//
//  • Change SERVER_NAME to your community's name.
//  • Add, remove, or reword questions in the SECTIONS array below.
//  • Each field needs a unique `name`. Set `required: true` to require it.
//  • `type` is "text" (single line) or "textarea" (paragraph).
//  • `inline: true` places short answers two-per-row in the Discord message.
//  • Keep `maxLength` at or below 1000 so answers fit Discord's limits.
// ─────────────────────────────────────────────────────────────────────────

export const SERVER_NAME = "Your Server";

export const SECTIONS = [
  {
    id: "about",
    number: "01",
    title: "About you",
    blurb: "The basics, so we know who we're talking to.",
    fields: [
      {
        name: "discordUsername",
        label: "Your Discord username",
        type: "text",
        required: true,
        inline: true,
        maxLength: 40,
        placeholder: "e.g. yourname",
      },
      {
        name: "discordId",
        label: "Your Discord user ID",
        type: "text",
        required: false,
        inline: true,
        maxLength: 25,
        placeholder: "e.g. 123456789012345678",
        help: "Turn on Developer Mode in Discord settings, then right-click your name and choose Copy User ID.",
      },
      {
        name: "age",
        label: "Your age",
        type: "text",
        required: true,
        inline: true,
        maxLength: 3,
        placeholder: "e.g. 17",
      },
      {
        name: "timezone",
        label: "Your timezone",
        type: "text",
        required: true,
        inline: true,
        maxLength: 40,
        placeholder: "e.g. EST / UTC+1",
      },
      {
        name: "hoursPerWeek",
        label: "Hours per week you can moderate",
        type: "text",
        required: true,
        inline: true,
        maxLength: 40,
        placeholder: "e.g. 10–15 hours",
      },
      {
        name: "memberDuration",
        label: "How long have you been in the server?",
        type: "text",
        required: true,
        inline: true,
        maxLength: 40,
        placeholder: "e.g. 8 months",
      },
    ],
  },
  {
    id: "experience",
    number: "02",
    title: "Experience",
    blurb: "Tell us where you're coming from. No experience is fine — be honest.",
    fields: [
      {
        name: "experience",
        label: "Previous moderation experience",
        type: "textarea",
        required: true,
        maxLength: 1000,
        placeholder:
          "Servers you've moderated, roles you've held, tools you've used. Never modded before? Just say so.",
      },
      {
        name: "motivation",
        label: "Why do you want to be a moderator here?",
        type: "textarea",
        required: true,
        maxLength: 1000,
        placeholder: "What makes you want to help run this community?",
      },
    ],
  },
  {
    id: "scenarios",
    number: "03",
    title: "Scenarios",
    blurb: "How you'd actually handle the job. There are no trick answers.",
    fields: [
      {
        name: "scenario1",
        label:
          "Two members start a heated argument in general chat. What do you do?",
        type: "textarea",
        required: true,
        maxLength: 1000,
        placeholder: "Walk us through your steps.",
      },
      {
        name: "scenario2",
        label:
          "You notice another staff member breaking the rules. How do you handle it?",
        type: "textarea",
        required: true,
        maxLength: 1000,
        placeholder: "Walk us through your steps.",
      },
    ],
  },
  {
    id: "wrapup",
    number: "04",
    title: "Wrap-up",
    blurb: "Last thing, then you're done.",
    fields: [
      {
        name: "additional",
        label: "Anything else you'd like us to know?",
        type: "textarea",
        required: false,
        maxLength: 1000,
        placeholder: "Optional — the floor is yours.",
      },
    ],
  },
];

// Flattened list of every field, used for validation and formatting.
export const ALL_FIELDS = SECTIONS.flatMap((s) => s.fields);
