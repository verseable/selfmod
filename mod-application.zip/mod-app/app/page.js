"use client";

import { useState } from "react";
import { SECTIONS, ALL_FIELDS, SERVER_NAME } from "./questions";

export default function Page() {
  const [values, setValues] = useState({});
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | submitting | success
  const [serverError, setServerError] = useState("");

  function update(name, val) {
    setValues((v) => ({ ...v, [name]: val }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: undefined }));
  }

  function validate() {
    const next = {};
    for (const f of ALL_FIELDS) {
      if (f.required && !String(values[f.name] || "").trim()) {
        next[f.name] = "This one's required.";
      }
    }
    setErrors(next);
    return next;
  }

  async function handleSubmit() {
    setServerError("");
    const found = validate();
    if (Object.keys(found).length) {
      const firstBad = ALL_FIELDS.find((f) => found[f.name]);
      if (firstBad) {
        document
          .getElementById(firstBad.name)
          ?.scrollIntoView({ behavior: "smooth", block: "center" });
      }
      return;
    }

    setStatus("submitting");
    try {
      const res = await fetch("/api/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setServerError(data.error || "Something went wrong. Please try again.");
        setStatus("idle");
        return;
      }

      setStatus("success");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      setServerError(
        "We couldn't reach the server. Check your connection and try again."
      );
      setStatus("idle");
    }
  }

  if (status === "success") {
    return (
      <main className="page">
        <div className="success">
          <div className="success-badge">
            <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path
                d="M5 13l4 4L19 7"
                stroke="currentColor"
                strokeWidth="2.4"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <h1>Application sent</h1>
          <p>
            Thanks for applying to the {SERVER_NAME} staff team. The
            moderators have your answers and will reach out on Discord if
            they'd like to talk further. You can close this page.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="page">
      <header className="header">
        <div className="badge">
          <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path
              d="M12 2L4 5v6c0 5 3.4 8.5 8 11 4.6-2.5 8-6 8-11V5l-8-3z"
              fill="currentColor"
              opacity="0.28"
            />
            <path
              d="M12 2L4 5v6c0 5 3.4 8.5 8 11 4.6-2.5 8-6 8-11V5l-8-3z"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinejoin="round"
            />
            <path
              d="M8.5 12l2.4 2.4L15.6 9.5"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
        <p className="eyebrow">{SERVER_NAME} · Staff</p>
        <h1>Moderator Application</h1>
        <p>
          Want to help keep this community running well? Fill this out
          honestly — it takes about ten minutes, and every answer gets read.
        </p>
      </header>

      {SECTIONS.map((section) => (
        <section className="section" key={section.id}>
          <div className="section-head">
            <div className="section-number">{section.number}</div>
            <div>
              <h2 className="section-title">{section.title}</h2>
              <p className="section-blurb">{section.blurb}</p>
            </div>
          </div>

          {section.id === "about" ? (
            <div className="grid">
              {section.fields.map((f) => (
                <Field
                  key={f.name}
                  field={f}
                  value={values[f.name] || ""}
                  error={errors[f.name]}
                  onChange={update}
                />
              ))}
            </div>
          ) : (
            section.fields.map((f) => (
              <Field
                key={f.name}
                field={f}
                value={values[f.name] || ""}
                error={errors[f.name]}
                onChange={update}
              />
            ))
          )}
        </section>
      ))}

      {/* Honeypot: real people never see or fill this. Bots often do. */}
      <input
        className="hp"
        type="text"
        name="_gotcha"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        value={values._gotcha || ""}
        onChange={(e) => update("_gotcha", e.target.value)}
      />

      <div className="submit-row">
        {serverError && <div className="server-error">{serverError}</div>}
        <button
          className="submit"
          type="button"
          onClick={handleSubmit}
          disabled={status === "submitting"}
        >
          {status === "submitting" ? "Sending…" : "Submit application"}
        </button>
        <p className="disclaimer">
          Your answers are sent privately to the {SERVER_NAME} moderators.
        </p>
      </div>
    </main>
  );
}

function Field({ field, value, error, onChange }) {
  const isText = field.type === "text";
  const showCount = field.type === "textarea" && field.maxLength;

  return (
    <div
      className={`field ${isText ? "" : "span"} ${error ? "error" : ""}`.trim()}
    >
      <label htmlFor={field.name}>
        {field.label}
        {field.required && <span className="req">*</span>}
        {showCount && (
          <span className="count">
            {value.length}/{field.maxLength}
          </span>
        )}
      </label>
      {field.help && <p className="help">{field.help}</p>}
      {isText ? (
        <input
          id={field.name}
          name={field.name}
          type="text"
          value={value}
          maxLength={field.maxLength}
          placeholder={field.placeholder}
          onChange={(e) => onChange(field.name, e.target.value)}
        />
      ) : (
        <textarea
          id={field.name}
          name={field.name}
          value={value}
          maxLength={field.maxLength}
          placeholder={field.placeholder}
          onChange={(e) => onChange(field.name, e.target.value)}
        />
      )}
      {error && <p className="error-text">{error}</p>}
    </div>
  );
}
