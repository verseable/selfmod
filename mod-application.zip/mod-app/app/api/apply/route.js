import { NextResponse } from "next/server";
import { ALL_FIELDS, SERVER_NAME } from "../../questions";

const WEBHOOK = process.env.DISCORD_WEBHOOK_URL;

function clip(str, max) {
  if (!str) return "";
  return str.length > max ? str.slice(0, max - 12) + "… [cut]" : str;
}

export async function POST(req) {
  if (!WEBHOOK) {
    return NextResponse.json(
      {
        error:
          "This form isn't connected yet. An admin needs to add the Discord webhook.",
      },
      { status: 500 }
    );
  }

  let data;
  try {
    data = await req.json();
  } catch {
    return NextResponse.json(
      { error: "We couldn't read your application. Please try again." },
      { status: 400 }
    );
  }

  // Honeypot: a filled hidden field means a bot. Pretend it worked, send nothing.
  if (data._gotcha) {
    return NextResponse.json({ ok: true });
  }

  // Server-side validation of required fields.
  const missing = ALL_FIELDS.filter(
    (f) => f.required && !String(data[f.name] || "").trim()
  ).map((f) => f.label);

  if (missing.length) {
    return NextResponse.json(
      { error: `Please fill in: ${missing.join(", ")}` },
      { status: 400 }
    );
  }

  // Build the Discord embed from answered fields.
  const embedFields = ALL_FIELDS.filter((f) =>
    String(data[f.name] || "").trim()
  ).map((f) => ({
    name: clip(f.label, 256),
    value: clip(String(data[f.name]).trim(), 1024),
    inline: Boolean(f.inline),
  }));

  const applicant = clip(String(data.discordUsername || "Unknown").trim(), 200);

  const embed = {
    title: "New moderator application",
    description: `**${applicant}** applied to join the ${SERVER_NAME} staff team.`,
    color: 0x5865f2,
    fields: embedFields.slice(0, 25),
    timestamp: new Date().toISOString(),
    footer: { text: `${SERVER_NAME} · Moderator applications` },
  };

  try {
    const res = await fetch(WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: `${SERVER_NAME} Applications`,
        embeds: [embed],
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      console.error("Discord webhook failed:", res.status, body);
      return NextResponse.json(
        {
          error:
            "We couldn't deliver your application. Please try again in a moment.",
        },
        { status: 502 }
      );
    }
  } catch (err) {
    console.error("Webhook request error:", err);
    return NextResponse.json(
      {
        error:
          "We couldn't deliver your application. Please try again in a moment.",
      },
      { status: 502 }
    );
  }

  return NextResponse.json({ ok: true });
}
